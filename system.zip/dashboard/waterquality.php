






<!DOCTYPE html>
<html>
<haed>
        <title>>Project_page1</title>
        
 <style>
            body {
               
            background-color: seagreen;
           
            }
            div.block img {
                  
                   width: 10%;
                   height: 10%;
                   float:right;
                   
                
            }
            div.block p{

                word-spacing:5px;
                text-decoration-color: darkgreen;
                font-size:150%;
                border: 1px solid green;
                background-color: green;
                padding-top: 50px;
                padding-right: 100px;
                padding-bottom: 4px;
                padding-left: 40px;
                margin-top: -6px;
                margin-left: -7px;
                margin-right: -7px;
            }
            


            div.block2 {

                border: 1px solid green;
                background-color: green;
                background-image: linear-gradient(red, yellow, green);
                padding-top: 10px;
                padding-bottom: 4px;
                padding-left: 10px;
                margin-top:-18px;
            }     
          .button {
                background-color: black;
                border:  2px solid #4CAF50;
                color: green;
                border-radius:50%;
                padding: 15px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                 }

  </style> 

</haed>  




<body>

      <div class="block">
                      
        <p>Water Quality Monitoring (PH,POH,Temparature,Dissolved oxyzen,Turbidity of water)</p>
                      
      </div>
     
      
    
  <div class="block2">
     
      <img src="pic1.jpg"  height="350" width="685">
      <img src="pic2.jpg"  height="350" width="700">
      
  </div>
   <br>
   <br>
   
   <a href = "table.php"> <input type="button" method = "POST" name = "submit" class="button" value="Show_Water_quality" action = ""> </a> 

   



</body>

</html>