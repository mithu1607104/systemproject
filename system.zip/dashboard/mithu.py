import serial
import time
arduino = serial.Serial('COM5', 9600)
i=-1
s=""
k=-1
while True:
        i+=1
        data = arduino.readline()[:-2]
        if data:
                s+=data.decode(encoding="utf-8"+" ")
                s+=" "
        if i==4:
                
                ss=s.split()
                file=open('table.php','w')
                file.write("""


                <!DOCTYPE html>
                <html>
                <head>
                        <title> Project_page1 </title>
                        
                 <style>
                            body {
                               
                            background-color: seagreen;
                           
                            }
                            div.block img {
                                  
                                   width: 10%;
                                   height: 10%;
                                   float:right;
                                   
                                
                            }
                            div.block p{

                                word-spacing:5px;
                                text-decoration-color: darkgreen;
                                font-size:150%;
                                border: 1px solid green;
                                background-color: green;
                                padding-top: 50px;
                                padding-right: 100px;
                                padding-bottom: 4px;
                                padding-left: 40px;
                                margin-top: -6px;
                                margin-left: -7px;
                                margin-right: -7px;
                            }
                            


                            div.block2 {

                                border: 1px solid green;
                                background-color: green;
                                background-image: linear-gradient(red, yellow, green);
                                padding-top: 10px;
                                padding-bottom: 4px;
                                padding-left: 10px;
                                margin-top:-18px;
                            }     
                          .button {
                                background-color: black;
                                border:  2px solid #4CAF50;
                                color: green;
                                border-radius:50%;
                                padding: 15px 32px;
                                text-align: center;
                                text-decoration: none;
                                display: inline-block;
                                font-size: 16px;
                                margin: 4px 2px;
                                cursor: pointer;
                                 }

                  </style> 
                  
                  

                </head>  




                <body onload=display_ct();>

                      <div class="block">
                                      
                        <p>Water Quality Monitoring (PH,POH,Temparature,Dissolved oxyzen,Turbidity of water)</p>
                                      
                      </div>
                     
                      
                    
                  
                   <br>
                   <br>
                   
                  

                   <div>
                        
                        <table border="1px" width="100%">
                           <thead>
                               <tr>
                                   <th>pH</th>
                                   <th>pOH</th>
                                   <th>Temparature</th>
                                   <th>Dissolved Oxygen</th>
                                   <th>Water Level</th>
                               </tr>
                           </thead>
                           <tbody>
                               <tr> 

                                   <td > <p id="d1" >""" + ss[0] + """ </p> </td>
                                   <td > <p id="d2" >""" + ss[1] + """ </p></td>
                                   <td > <p id="d3" >""" + ss[2] + """ </p> </td>
                                   <td>  <p id="d4" >""" + ss[3] + """ </p></td>
                                   <td>  <p id="d5" >""" + ss[4] + """ </p></td>


                               </tr>
                               
                           </tbody>
                         
                        </table>
                </div>




                </body>


                </html>""")
                file.close()
                print(s)
                print(ss)
                s=""
                i=-1
                
                

        

